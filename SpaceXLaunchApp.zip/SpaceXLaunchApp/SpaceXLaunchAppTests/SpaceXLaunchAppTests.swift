//
//  SpaceXLaunchAppTests.swift
//  SpaceXLaunchAppTests
//
//  Created by Tristan Newman on 1/11/19.
//  Copyright © 2019 Tristan Newman. All rights reserved.
//

import XCTest
@testable import SpaceXLaunchApp

class SpaceXLaunchAppTests: XCTestCase {

    //MARK: Launch Class Test
    
    //Confirms the Launch initializer returns a valid object when passed valid parameters
    func testLaunchInitializerSuccess(){
        var helloWorld: String?
        
        XCTAssertNil(helloWorld)
    }
}
