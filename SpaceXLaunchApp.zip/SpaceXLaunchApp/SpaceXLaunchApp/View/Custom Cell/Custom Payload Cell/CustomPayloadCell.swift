//
//  LaunchViewTableViewCell.swift
//  SpaceXLaunchApp
//
//  Created by Tristan Newman on 1/13/19.
//  Copyright © 2019 Tristan Newman. All rights reserved.
//

import UIKit

class CustomPayloadCell: UITableViewCell {

    //MARK: Properties
    @IBOutlet weak var payloadIDName: UILabel!
    @IBOutlet weak var nationalityName: UILabel!
    @IBOutlet weak var manufacturerName: UILabel!
    //Variables
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
