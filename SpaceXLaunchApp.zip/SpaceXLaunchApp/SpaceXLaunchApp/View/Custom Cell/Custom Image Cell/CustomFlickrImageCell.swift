//
//  CustomFlickrImageCell.swift
//  SpaceXLaunchAppCustomImageCell
//
//  Created by Tristan Newman on 2/3/19.
//  Copyright © 2019 Tristan Newman. All rights reserved.
//

import UIKit

class CustomFlickrImageCell: UITableViewCell{
    
}
