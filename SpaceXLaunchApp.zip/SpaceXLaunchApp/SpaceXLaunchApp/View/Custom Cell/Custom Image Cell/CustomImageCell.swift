//
//  CustomImageCell.swift
//  SpaceXLaunchApp
//
//  Created by Tristan Newman on 2/3/19.
//  Copyright © 2019 Tristan Newman. All rights reserved.
//

import UIKit

class CustomImageCell: UITableViewCell{
    
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
}
