//
//  LaunchViewController.swift
//  SpaceXLaunchApp
//
//  Created by Tristan Newman on 1/11/19.
//  Copyright © 2019 Tristan Newman. All rights reserved.
//

import Foundation
import UIKit

class LaunchViewController: UIViewController, UITableViewDelegate, UITableViewDataSource{
    
    
    //MARK: Properties
    
    //Variable
    @IBOutlet weak var viewTitle: UILabel!
    @IBOutlet weak var viewCaption1: UILabel!
    @IBOutlet weak var viewCaption2: UILabel!
    @IBOutlet weak var viewMessage: UILabel!
    @IBAction func backButtonPressed(_ sender: Any) {
    }
    @IBOutlet weak var imageTable: UITableView!
    @IBOutlet weak var payloadTableView: UITableView!
    
    var selectedLaunch: Launch!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        payloadTableView.delegate = self
        payloadTableView.dataSource = self
        loadLaunchData(launch: selectedLaunch!)
        
        //Resgistering nibs
        payloadTableView.register(UINib(nibName: "PayloadCell", bundle: nil), forCellReuseIdentifier: "customPayloadCell")
        configureTableView()
        payloadTableView.reloadData()
        
        //Cell height adjustment for content
        
    }
    
    func loadLaunchData(launch: Launch){
        
        self.viewTitle.text = launch.missionName
        self.viewCaption1.text = launch.rocketType
        self.viewCaption2.text = launch.launchDate
        self.viewMessage.text = launch.launchMessage
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return selectedLaunch.payloads.payloadIds.count 
    }
    
    //MARK: - TableView DataSource Methods
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "customPayloadCell", for: indexPath) as! CustomPayloadCell
        
        cell.payloadIDName.text = selectedLaunch.payloads.payloadIds[indexPath.row]
        cell.nationalityName.text = selectedLaunch.payloads.nationalities[indexPath.row]
        cell.manufacturerName.text = selectedLaunch.payloads.manufacturers[indexPath.row]
        return cell
    }
    
    func configureTableView(){
        payloadTableView.rowHeight = UITableView.automaticDimension
        payloadTableView.estimatedRowHeight = 80.0
    }
}
