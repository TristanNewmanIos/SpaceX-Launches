//
//  LaunchTableViewCell.swift
//  SpaceXLaunchApp
//
//  Created by Tristan Newman on 1/11/19.
//  Copyright © 2019 Tristan Newman. All rights reserved.
//

import UIKit

class LaunchTableViewCell: UITableViewCell {
    
    //MARK: Properties
    @IBOutlet weak var cellImage: UIImageView!
    @IBOutlet weak var cellTitle: UILabel!
    @IBOutlet weak var cellCaption1: UILabel!
    @IBOutlet weak var cellCaption2: UILabel!
    @IBOutlet weak var cellCaption3: UILabel!
    @IBOutlet weak var cellView: UIView!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
