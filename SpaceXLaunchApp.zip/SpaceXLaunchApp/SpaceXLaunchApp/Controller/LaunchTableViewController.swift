//
//  LaunchTableViewController.swift
//  SpaceXLaunchApp
//
//  Created by Tristan Newman on 1/11/19.
//  Copyright © 2019 Tristan Newman. All rights reserved.
//

import UIKit
import Foundation
import Alamofire
import SwiftyJSON
import SDWebImage

class LaunchTableViewController: UITableViewController{
    
    //MARK: - Properties
    /************************************************************************************************************/
    var completeLaunchList = LaunchList(size: 1)
    
    //Constants
    let SPACEX_URL = "https://api.spacexdata.com/v3/launches"
    
    
    //MARK: - Public methods
    /************************************************************************************************************/
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Gets SpaceX launch data
        getLaunchData(url: SPACEX_URL)
    }
    
    //MARK: Table view datasource methods
    /************************************************************************************************************/
    
    //Sets number of rows in table to number of launches in array
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return completeLaunchList.list.count
    }
    
    //Makes cells reusable and configures cells without data
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "LaunchTableViewCell", for: indexPath) as! LaunchTableViewCell
        
        // Configures the cell
        cell.cellImage.sd_setImage(with:URL(string: completeLaunchList.list[indexPath.row].patchImageURL))
        cell.cellTitle.text = completeLaunchList.list[indexPath.row].missionName
        cell.cellCaption1.text = completeLaunchList.list[indexPath.row].rocketName
        cell.cellCaption2.text = completeLaunchList.list[indexPath.row].rocketType
        cell.cellCaption3.text = String(completeLaunchList.list[indexPath.row].launchDate)

        print("Cell table view method complete")
        
        return cell
    }
    
    //MARK: Table view delegate methods
    /************************************************************************************************************/
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "toLaunchView", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let destinationVC = segue.destination as! LaunchViewController
        let indexPath = tableView.indexPathForSelectedRow!
        destinationVC.selectedLaunch = completeLaunchList.list[indexPath.row]
        
    }
    
    //MARK: - Networking
    /************************************************************************************************************/
 
    func getLaunchData(url: String){
        
        Alamofire.request(url, method: .get).responseJSON{
            response in
            if response.result.isSuccess{
                print("Launch data. Great success.")
                
                let launchJSON : JSON = JSON(response.result.value!)
                self.loadLaunchData(json: launchJSON)
            }
            else{
                print("There's an error \(response.result.error)")
            }
        }
        
    }
    
    //MARK: - JSON Parsing
    /************************************************************************************************************/
    
    //updateLaunchData method:
    func loadLaunchData (json : JSON){
        
        let launchCount = json.count;
        //Builts a launch list
        var launchList = LaunchList.init(size: launchCount)
        
        for i in 0..<launchCount{
            
            //Converts Epoch time in UTC time zone to YYYY:MM:DD HH:MM:SS CST
            var launchTimeEpochUTC = json[i]["launch_date_unix"].doubleValue
            var launchTimeHumanCST = NSDate(timeIntervalSince1970: (launchTimeEpochUTC - 600000.0))
            
            //Unpacks payload info
            var payloadCount = json[i]["rocket"]["second_stage"]["payloads"].count
            
            for j in 0..<payloadCount{
            
                var payloadId = json[i]["rocket"]["second_stage"]["payloads"][j]["payload_id"].stringValue
                var nationality = json[i]["rocket"]["second_stage"]["payloads"][j]["nationality"].stringValue
                var manufacturer = json[i]["rocket"]["second_stage"]["payloads"][j]["manufacturer"].stringValue
            
                launchList.list[i].payloads.payloadIds.append(payloadId)
                launchList.list[i].payloads.nationalities.append(nationality)
                launchList.list[i].payloads.manufacturers.append(manufacturer)
            }
                
            //Unpacks flickr image URL array
            var flickrArrayJSON = json[i]["links"]["flickr_images"].arrayValue
            var flickrImages = [String]()
            
            for j in 0..<flickrArrayJSON.count{
                
                flickrImages.append(flickrArrayJSON[j].stringValue)
            }
            
            
            
            
            launchList.list[i].patchImageURL = json[i]["links"]["mission_patch_small"].stringValue
            launchList.list[i].missionName = json[i]["mission_name"].stringValue
            launchList.list[i].rocketName = json[i]["rocket"]["rocket_name"].stringValue
            launchList.list[i].rocketType = json[i]["rocket"]["rocket_type"].stringValue
            launchList.list[i].launchDate = launchTimeHumanCST.description
            launchList.list[i].launchMessage = json[i]["details"].stringValue
            launchList.list[i].flickrPics = flickrImages
            
        }
        
        print(launchList.list[32].missionName)
        completeLaunchList = launchList
        self.tableView.reloadData()
        
    }
    
    
}
