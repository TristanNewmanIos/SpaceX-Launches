//
//  Launch.swift
//  SpaceXLaunchApp
//
//  Created by Tristan Newman on 1/11/19.
//  Copyright © 2019 Tristan Newman. All rights reserved.
//

import Foundation
import UIKit

class Launch {
    
    //MARK: - Properties
    /************************************************************************************************************/
    var patchImageURL: String = "cell-image1"
    var missionName: String = "Cornera"
    var rocketName: String = "Arwing"
    var rocketType: String = "Starfighter"
    var launchDate: String = "Feb 2, 1993"
    var launchMessage: String = "Reports indicate Andross is working on some secret weapon."
    var payloads = Payload(payloadIds: [String](), nationalities: [String](), manufacturers: [String]())!
    var flickrPics: [String] = [
        "https://starfox.fandom.com/wiki/Slippy_Toad?file=Slippy1.jpg",
        "http://nintendo.wikia.com/wiki/Falco_Lombardi?file=Falco_SFZ.png",
        "http://nintendo.wikia.com/wiki/Peppy_Hare?file=SFZ-Peppy_Hare.png",
        "http://nintendo.wikia.com/wiki/Fox_McCloud?file=Fox_McCloud_SFZ.png"
        ]
    
    //MARK - Initializer
    init!(patch: String, mission: String, rocket: String, type: String, date: String, message: String, flickrImages: [String]){
        
        patchImageURL = patch
        missionName = mission
        rocketName = rocket
        rocketType = type
        launchDate = date
        launchMessage = message
        flickrPics = flickrImages
    }
    
}
