//
//  LaunchBank.swift
//  SpaceXLaunchApp
//
//  Created by Tristan Newman on 1/11/19.
//  Copyright © 2019 Tristan Newman. All rights reserved.
//

import Foundation
import SwiftyJSON

class LaunchList{
    
    var list = [Launch]()
    
    init(size: Int){
        
        //Creates a launch item and appends it to the list
        for i in 0..<size{
            let item = Launch(patch: "https://images2.imgbox.com/40/e3/GypSkayF_o.png", mission: "FalconSat", rocket: "Falcon 1", type: "Merlin A", date: "Feb 2, 1993", message: "Engine failure at 33 seconds and loss of vehicle", flickrImages: [""])
        
            //Add the Launch item to the list
            list.append(item!)
        }
        
    }
}
