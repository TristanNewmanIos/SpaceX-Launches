//
//  Payload.swift
//  SpaceXLaunchApp
//
//  Created by Tristan Newman on 1/12/19.
//  Copyright © 2019 Tristan Newman. All rights reserved.
//

import Foundation

class Payload{
    
    var payloadIds : [String]
    var nationalities : [String]
    var manufacturers : [String]
    
    
    init!(payloadIds: [String]?, nationalities: [String]?, manufacturers: [String]?){
        
        self.payloadIds = payloadIds!
        self.nationalities = nationalities!
        self.manufacturers = manufacturers!
    }
}
